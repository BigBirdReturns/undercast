set -euo pipefail
rm -rf "$RECOVERY_ROOT"
mkdir -p "$RECOVERY_ROOT"/{api,archive,extracted}
test "$(git rev-parse HEAD)" = "$PR_HEAD"
test "$PR_BASE_SHA" = "$EXACT_MAIN"
test "$(git rev-list --count "$EXACT_MAIN"..HEAD)" = 1
test -z "$(git rev-list --merges "$EXACT_MAIN"..HEAD)"
test "$(git diff --name-only "$EXACT_MAIN"...HEAD)" = "$SELF"
test "$(git diff --name-status "$EXACT_MAIN"...HEAD)" = $'A\t'"$SELF"
test "$(gh api "/repos/$GITHUB_REPOSITORY/git/ref/heads/main" --jq '.object.sha')" = "$EXACT_MAIN"

gh api "/repos/$GITHUB_REPOSITORY/actions/runs/$RECOVERY_RUN" > "$RECOVERY_ROOT/api/run.json"
gh api "/repos/$GITHUB_REPOSITORY/actions/jobs/$RECOVERY_JOB" > "$RECOVERY_ROOT/api/job.json"
gh api "/repos/$GITHUB_REPOSITORY/actions/artifacts/$RECOVERY_ARTIFACT" > "$RECOVERY_ROOT/api/artifact.json"
jq -e --argjson id "$RECOVERY_RUN" --arg h "$RECOVERY_HEAD" '.id==$id and .status=="completed" and .conclusion=="failure" and .head_sha==$h' "$RECOVERY_ROOT/api/run.json" >/dev/null
jq -e --argjson id "$RECOVERY_JOB" --argjson run "$RECOVERY_RUN" '.id==$id and .run_id==$run and .status=="completed" and .conclusion=="failure"' "$RECOVERY_ROOT/api/job.json" >/dev/null
jq -e --argjson id "$RECOVERY_ARTIFACT" --argjson run "$RECOVERY_RUN" --arg h "$RECOVERY_HEAD" --arg d "sha256:$RECOVERY_ZIP_SHA256" '.id==$id and .expired==false and .digest==$d and .workflow_run.id==$run and .workflow_run.head_sha==$h' "$RECOVERY_ROOT/api/artifact.json" >/dev/null
gh api "/repos/$GITHUB_REPOSITORY/actions/artifacts/$RECOVERY_ARTIFACT/zip" > "$RECOVERY_ROOT/archive/recovery.zip"
test "$(sha256sum "$RECOVERY_ROOT/archive/recovery.zip" | cut -d' ' -f1)" = "$RECOVERY_ZIP_SHA256"

ROOT="$RECOVERY_ROOT" python3 - <<'PY'
import hashlib, os, pathlib, re, zipfile

root = pathlib.Path(os.environ['ROOT'])
archive = root / 'archive/recovery.zip'
target = root / 'extracted'
with zipfile.ZipFile(archive) as z:
    infos = z.infolist()
    assert infos and len(infos) == len({i.filename for i in infos})
    for info in infos:
        path = pathlib.PurePosixPath(info.filename)
        assert not path.is_absolute() and '..' not in path.parts
        if not info.is_dir():
            output = target / path
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_bytes(z.read(info))

wrapper = target / 'doctor-who-cycle-009-megnus-jaka-selected-portrait-recovery-v5' / 'extracted' / 'doctor-who-cycle-009-megnus-jaka-selected-portrait-wrapper-v4'
script = wrapper / 'materialize.sh'
assert script.is_file()
source = script.read_bytes()
assert hashlib.sha256(source).hexdigest() == os.environ['SOURCE_MATERIALIZER_SHA256']
text = source.decode()
old = """echo '>>> Run complete rendered candidate gate'
set -euo pipefail
npm run gate 2>&1 | tee "$OUT/receipt/complete-gate.log"
"""
new = """echo '>>> Run complete rendered candidate gate'
set -euo pipefail
git add -A -- CREDITS.md data images sitemap.xml
test -z "$(git diff --name-only)"
npm run gate 2>&1 | tee "$OUT/receipt/complete-gate.log"
"""
assert text.count(old) == 1
text = text.replace(old, new)
assert text.count('git add -A -- CREDITS.md data images sitemap.xml') == 1
script.write_text(text)
assert hashlib.sha256(script.read_bytes()).hexdigest() == os.environ['PATCHED_MATERIALIZER_SHA256']
blocks = re.findall(r"python3 - <<'PY'\n(.*?)\nPY", text, re.S)
assert len(blocks) == 10
for index, block in enumerate(blocks, 1):
    compile(block, f'embedded-python-{index}', 'exec')
portrait = wrapper / 'portrait'
assert portrait.is_dir()
pathlib.Path(root / 'materializer-path.txt').write_text(str(script) + '\n')
pathlib.Path(root / 'portrait-root.txt').write_text(str(portrait) + '\n')
PY

script="$(cat "$RECOVERY_ROOT/materializer-path.txt")"
export PORTRAIT_ROOT="$(cat "$RECOVERY_ROOT/portrait-root.txt")"
test "$(wc -c < "$script")" = "$V7_MATERIALIZER_BYTES"
test "$(sha256sum "$script" | cut -d' ' -f1)" = "$V7_MATERIALIZER_SHA256"
SCRIPT="$script" python3 - <<'PY_PATCH'
import hashlib, os, re
from pathlib import Path
path=Path(os.environ['SCRIPT'])
text=path.read_text()
v7_line="events = [row for row in journal if row.get('task_id') == os.environ['TASK_ID']]"
v8_lines="lease_id = (root / 'receipt/lease-id.txt').read_text().strip()\nevents = [row for row in journal if row.get('task_id') == os.environ['TASK_ID'] and row.get('lease_id') == lease_id]"
assert text.count(v7_line)==1
text=text.replace(v7_line,v8_lines)
assert len(text.encode())==int(os.environ['V8_MATERIALIZER_BYTES'])
assert hashlib.sha256(text.encode()).hexdigest()==os.environ['V8_MATERIALIZER_SHA256']
old="""lease_id = (root / 'receipt/lease-id.txt').read_text().strip()
events = [row for row in journal if row.get('task_id') == os.environ['TASK_ID'] and row.get('lease_id') == lease_id]
assert [row['op'] for row in events] == ['lease.claimed', 'task.drafted', 'task.merged', 'task.media-verified']
assert [row['at'] for row in events] == [os.environ['CLAIM_AT'], os.environ['SUBMIT_AT'], os.environ['MERGE_AT'], os.environ['REVIEW_AT']]"""
new="""lease_id = (root / 'receipt/lease-id.txt').read_text().strip()
task_id = os.environ['TASK_ID']
wall_ids = [os.environ['EXPECTED_WALL_ID']]
indexed = list(enumerate(journal))

def one_lease_event(op, at):
    matches = [
        (index, row)
        for index, row in indexed
        if row.get('task_id') == task_id
        and row.get('op') == op
        and row.get('at') == at
        and row.get('lease_id') == lease_id
    ]
    assert len(matches) == 1
    return matches[0]

claimed = one_lease_event('lease.claimed', os.environ['CLAIM_AT'])
drafted = one_lease_event('task.drafted', os.environ['SUBMIT_AT'])
reviewed = one_lease_event('task.media-verified', os.environ['REVIEW_AT'])
merged = [
    (index, row)
    for index, row in indexed
    if drafted[0] < index < reviewed[0]
    and row.get('task_id') == task_id
    and row.get('op') == 'task.merged'
    and row.get('at') == os.environ['MERGE_AT']
    and row.get('wall_ids') == wall_ids
]
assert len(merged) == 1
merged = merged[0]
assert claimed[0] < drafted[0] < merged[0] < reviewed[0]
assert merged[1].get('lease_id') is None
assert reviewed[1].get('status') == 'resolved'
assert reviewed[1].get('wall_ids') == wall_ids"""
assert text.count(old)==1
text=text.replace(old,new)
assert text.count(old)==0
path.write_text(text)
assert len(path.read_bytes())==int(os.environ['V9_MATERIALIZER_BYTES'])
assert hashlib.sha256(path.read_bytes()).hexdigest()==os.environ['V9_MATERIALIZER_SHA256']
old_v9="""assert merged[1].get('lease_id') is None
assert reviewed[1].get('status') == 'resolved'
assert reviewed[1].get('wall_ids') == wall_ids"""
new_v10="""assert set(merged[1]) == {'op', 'task_id', 'at', 'scope', 'performer', 'character', 'wall_ids'}
assert set(reviewed[1]) == {'op', 'task_id', 'at', 'scope', 'performer', 'character', 'lease_id', 'reviewed_by', 'wall_ids', 'review_sha256'}
assert reviewed[1]['scope'] == job['scope']
assert reviewed[1]['performer'] == job['performer']
assert reviewed[1]['character'] == job['character']
assert reviewed[1]['reviewed_by'] == 'chatgpt-second-desk'
assert reviewed[1]['review_sha256'] == job['outcome']['review_sha256']
assert reviewed[1]['wall_ids'] == wall_ids"""
assert text.count(old_v9)==1
text=text.replace(old_v9,new_v10)
assert text.count(old_v9)==0
path.write_text(text)
assert len(path.read_bytes())==int(os.environ['V10_MATERIALIZER_BYTES'])
assert hashlib.sha256(path.read_bytes()).hexdigest()==os.environ['V10_MATERIALIZER_SHA256']
blocks=re.findall(r"python3 - <<'PY'\n(.*?)\nPY", text, re.S)
assert len(blocks)==10
for index, block in enumerate(blocks, 1):
    compile(block, f'embedded-python-{index}', 'exec')
PY_PATCH
SCRIPT="$script" python3 - <<'PY_V10T'
import hashlib, os
from pathlib import Path
path=Path(os.environ['SCRIPT'])
text=path.read_text()
old_merged="assert set(merged[1]) == {'op', 'task_id', 'at', 'scope', 'performer', 'character', 'wall_ids'}"
new_merged="assert set(merged[1]) == {'id', 'version', 'op', 'task_id', 'at', 'scope', 'performer', 'character', 'wall_ids'}"
old_reviewed="assert set(reviewed[1]) == {'op', 'task_id', 'at', 'scope', 'performer', 'character', 'lease_id', 'reviewed_by', 'wall_ids', 'review_sha256'}"
new_reviewed="assert set(reviewed[1]) == {'id', 'version', 'op', 'task_id', 'at', 'scope', 'performer', 'character', 'lease_id', 'reviewed_by', 'wall_ids', 'review_sha256'}"
assert text.count(old_merged)==1 and text.count(old_reviewed)==1
text=text.replace(old_merged,new_merged).replace(old_reviewed,new_reviewed)
assert old_merged not in text and old_reviewed not in text
path.write_text(text)
assert len(path.read_bytes())==int(os.environ['V10T_MATERIALIZER_BYTES'])
assert hashlib.sha256(path.read_bytes()).hexdigest()==os.environ['V10T_MATERIALIZER_SHA256']
PY_V10T
bash -n "$script"
chmod 700 "$script"
"$script"
mkdir -p "$OUT/source"
cp "$script" "$OUT/source/materialize-v10.sh"
sha256sum "$script" > "$OUT/source/materialize-v10.sha256"
