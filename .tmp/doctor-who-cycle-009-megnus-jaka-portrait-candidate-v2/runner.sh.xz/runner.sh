#!/usr/bin/env bash
set -euo pipefail

rm -rf "$WRAP"
mkdir -p "$WRAP"/{api,archive,candidate,portrait}
test "$(git rev-parse HEAD)" = "$PR_HEAD"
test "$PR_BASE_SHA" = "$EXACT_MAIN"
test "$(gh api "/repos/$GITHUB_REPOSITORY/git/ref/heads/main" --jq '.object.sha')" = "$EXACT_MAIN"

gh api "/repos/$GITHUB_REPOSITORY/actions/runs/$FAILED_RUN" > "$WRAP/api/failed-run.json"
gh api "/repos/$GITHUB_REPOSITORY/actions/jobs/$FAILED_JOB" > "$WRAP/api/failed-job.json"
gh api "/repos/$GITHUB_REPOSITORY/actions/artifacts/$DIAGNOSTICS_ARTIFACT" > "$WRAP/api/failed-artifact.json"
jq -e --argjson id "$FAILED_RUN" --arg h "$FAILED_HEAD" '.id==$id and .status=="completed" and .conclusion=="failure" and .head_sha==$h' "$WRAP/api/failed-run.json" >/dev/null
jq -e --argjson id "$FAILED_JOB" --argjson run "$FAILED_RUN" '.id==$id and .run_id==$run and .status=="completed" and .conclusion=="failure"' "$WRAP/api/failed-job.json" >/dev/null
jq -e --argjson id "$DIAGNOSTICS_ARTIFACT" --argjson run "$FAILED_RUN" --arg h "$FAILED_HEAD" --arg d "sha256:$DIAGNOSTICS_ZIP_SHA256" '.id==$id and .expired==false and .digest==$d and .workflow_run.id==$run and .workflow_run.head_sha==$h' "$WRAP/api/failed-artifact.json" >/dev/null

gh api "/repos/$GITHUB_REPOSITORY/actions/runs/$PORTRAIT_RUN" > "$WRAP/api/portrait-run.json"
gh api "/repos/$GITHUB_REPOSITORY/actions/jobs/$PORTRAIT_JOB" > "$WRAP/api/portrait-job.json"
gh api "/repos/$GITHUB_REPOSITORY/actions/artifacts/$PORTRAIT_ARTIFACT" > "$WRAP/api/portrait-artifact.json"
jq -e --argjson id "$PORTRAIT_RUN" --arg h "$PORTRAIT_HEAD" '.id==$id and .status=="completed" and .conclusion=="success" and .head_sha==$h' "$WRAP/api/portrait-run.json" >/dev/null
jq -e --argjson id "$PORTRAIT_JOB" --argjson run "$PORTRAIT_RUN" '.id==$id and .run_id==$run and .status=="completed" and .conclusion=="success"' "$WRAP/api/portrait-job.json" >/dev/null
jq -e --argjson id "$PORTRAIT_ARTIFACT" --argjson run "$PORTRAIT_RUN" --arg h "$PORTRAIT_HEAD" --arg d "sha256:$PORTRAIT_ZIP_SHA256" '.id==$id and .expired==false and .digest==$d and .workflow_run.id==$run and .workflow_run.head_sha==$h' "$WRAP/api/portrait-artifact.json" >/dev/null

gh api "/repos/$GITHUB_REPOSITORY/actions/artifacts/$DIAGNOSTICS_ARTIFACT/zip" > "$WRAP/archive/candidate.zip"
gh api "/repos/$GITHUB_REPOSITORY/actions/artifacts/$PORTRAIT_ARTIFACT/zip" > "$WRAP/archive/portrait.zip"
test "$(sha256sum "$WRAP/archive/candidate.zip" | cut -d' ' -f1)" = "$DIAGNOSTICS_ZIP_SHA256"
test "$(sha256sum "$WRAP/archive/portrait.zip" | cut -d' ' -f1)" = "$PORTRAIT_ZIP_SHA256"

ROOT="$WRAP" python3 - <<'PY'
import hashlib, json, os, pathlib, zipfile
root=pathlib.Path(os.environ['ROOT'])
def extract(source,target):
    target.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(source) as z:
        infos=z.infolist(); assert infos and len(infos)==len({i.filename for i in infos})
        for i in infos:
            p=pathlib.PurePosixPath(i.filename); assert not p.is_absolute() and '..' not in p.parts
            if not i.is_dir():
                out=target/p; out.parent.mkdir(parents=True,exist_ok=True); out.write_bytes(z.read(i))
extract(root/'archive/candidate.zip',root/'candidate')
extract(root/'archive/portrait.zip',root/'portrait')
source=root/'candidate/megnus-jaka-materializer/materialize.sh'
assert source.is_file() and hashlib.sha256(source.read_bytes()).hexdigest()==os.environ['SOURCE_MATERIALIZER_SHA256']
portrait=root/'portrait'
for row in (portrait/'SHA256SUMS').read_text().splitlines():
    digest,name=row.split(None,1); p=portrait/pathlib.Path(name).name
    assert p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==digest
review=json.loads((portrait/'portrait-review.json').read_text()); rid=review.pop('identity')
assert hashlib.sha256(json.dumps(review,sort_keys=True,separators=(',',':')).encode()).hexdigest()==rid==os.environ['PORTRAIT_REVIEW_IDENTITY']
metadata=json.loads((portrait/'commons-metadata.json').read_text()); mid=metadata.pop('identity')
assert hashlib.sha256(json.dumps(metadata,sort_keys=True,separators=(',',':')).encode()).hexdigest()==mid==os.environ['PORTRAIT_METADATA_IDENTITY']
assert review['visual_identity_claim'] is False and review['source_file_page']==os.environ['PORTRAIT_ORIGIN']
assert review['derivative']['sha256']==os.environ['PORTRAIT_SHA256'] and review['canonical_origin_match'] is False and review['canonical_hash_match'] is False
assert metadata['source_assignment_only'] is True and metadata['visual_identity_claim'] is False and metadata['file_page']==os.environ['PORTRAIT_ORIGIN']
asset=portrait/'uc-1354-portrait.jpg'; assert hashlib.sha256(asset.read_bytes()).hexdigest()==os.environ['PORTRAIT_SHA256']
PY

ROOT="$WRAP" python3 - <<'PY'
import hashlib,json,os,pathlib
root=pathlib.Path(os.environ['ROOT']); carrier=pathlib.Path(os.environ['CARRIER_DIR'])
manifest=json.loads((carrier/'manifest.json').read_text()); identity=manifest.pop('identity')
assert hashlib.sha256(json.dumps(manifest,sort_keys=True,separators=(',',':')).encode()).hexdigest()==identity==os.environ['CARRIER_MANIFEST_IDENTITY']
assert manifest['exact_main']==os.environ['EXACT_MAIN'] and manifest['branch']==os.environ['BRANCH']
assert manifest['runner']['sha256']==os.environ['RUNNER_SHA256'] and manifest['runner']['xz_sha256']==os.environ['RUNNER_XZ_SHA256']
assert manifest['materializer_patch']['sha256']==os.environ['MATERIALIZER_PATCH_SHA256'] and manifest['materializer_patch']['xz_sha256']==os.environ['MATERIALIZER_PATCH_XZ_SHA256']
assert manifest['patched_materializer_sha256']==os.environ['PATCHED_MATERIALIZER_SHA256']
assert (carrier/'runner.sha256').read_text().strip()==os.environ['RUNNER_SHA256']
assert (carrier/'materializer.patch.sha256').read_text().strip()==os.environ['MATERIALIZER_PATCH_SHA256']
parts=[carrier/'materializer.patch.xz.part-00',carrier/'materializer.patch.xz.part-01']
compressed=b''.join(p.read_bytes() for p in parts)
assert hashlib.sha256(compressed).hexdigest()==os.environ['MATERIALIZER_PATCH_XZ_SHA256']
(root/'materializer.patch.xz').write_bytes(compressed)
PY
xz -dc "$WRAP/materializer.patch.xz" > "$WRAP/materializer.patch"
test "$(sha256sum "$WRAP/materializer.patch" | cut -d' ' -f1)" = "$MATERIALIZER_PATCH_SHA256"
cp "$WRAP/candidate/megnus-jaka-materializer/materialize.sh" "$WRAP/materialize.sh"
(cd "$WRAP" && patch --batch --fuzz=0 -p0 < materializer.patch)
test "$(sha256sum "$WRAP/materialize.sh" | cut -d' ' -f1)" = "$PATCHED_MATERIALIZER_SHA256"
bash -n "$WRAP/materialize.sh"
SCRIPT="$WRAP/materialize.sh" python3 - <<'PY'
import os,re
text=open(os.environ['SCRIPT']).read()
blocks=re.findall(r"python3 - <<'PY'\n(.*?)\nPY",text,re.S)
assert len(blocks)==10, len(blocks)
for index,block in enumerate(blocks,1): compile(block,f'embedded-python-{index}','exec')
PY
chmod 700 "$WRAP/materialize.sh"
export PORTRAIT_ROOT="$WRAP/portrait"
test "$(gh api "/repos/$GITHUB_REPOSITORY/git/ref/heads/main" --jq '.object.sha')" = "$EXACT_MAIN"
test -z "$(git status --porcelain)"
exec "$WRAP/materialize.sh"
