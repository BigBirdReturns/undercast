#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
from typing import Any
import hashlib
import json
import os
import subprocess
import sys

OUT = Path(os.environ["OUT"])
LIVE_MAIN = os.environ["LIVE_MAIN"]
LIVE_TREE = os.environ["LIVE_TREE"]
LIVE_MESSAGE = os.environ["LIVE_MESSAGE"]
PREDECESSOR_PRODUCT = os.environ["PREDECESSOR_PRODUCT"]
PREDECESSOR_TREE = os.environ["PREDECESSOR_TREE"]
CLAIM_COMMIT = os.environ["CLAIM_COMMIT"]
CLAIM_TREE = os.environ["CLAIM_TREE"]
CLAIM_RECEIPT_SHA = os.environ["CLAIM_RECEIPT_SHA"]
SOURCE_REVIEW_SHA = os.environ["SOURCE_REVIEW_SHA"]
MEDIA_RECEIPT_SHA = os.environ["MEDIA_RECEIPT_SHA"]
MEDIA_REVIEW_SHA = os.environ["MEDIA_REVIEW_SHA"]
CANDIDATE_COMMIT = os.environ["CANDIDATE_COMMIT"]
CANDIDATE_TREE = os.environ["CANDIDATE_TREE"]
CANDIDATE_RECEIPT_SHA = os.environ["CANDIDATE_RECEIPT_SHA"]
REVIEW_COMMIT = os.environ["REVIEW_COMMIT"]
REVIEW_SHA = os.environ["REVIEW_SHA"]
TASK_ID = os.environ["TASK_ID"]
PERFORMER = os.environ["PERFORMER"]
CHARACTER = os.environ["CHARACTER"]
FINGERPRINT = os.environ["FINGERPRINT"]
LEASE_ID = os.environ["LEASE_ID"]
WALL_ID = os.environ["WALL_ID"]
STILL_SHA = os.environ["STILL_SHA"]
PORTRAIT_SHA = os.environ["PORTRAIT_SHA"]
STILL_ITEM = os.environ["STILL_ITEM"]
PORTRAIT_ITEM = os.environ["PORTRAIT_ITEM"]
PREDECESSOR_RECEIPT_PATH = Path(os.environ["PREDECESSOR_RECEIPT_PATH"])
PREDECESSOR_RECEIPT_SHA = os.environ["PREDECESSOR_RECEIPT_SHA"]
PREDECESSOR_CHECKER_PATH = Path(os.environ["PREDECESSOR_CHECKER_PATH"])
PREDECESSOR_CHECKER_SHA = os.environ["PREDECESSOR_CHECKER_SHA"]
PREDECESSOR_CYCLE_ID = os.environ["PREDECESSOR_CYCLE_ID"]
RECEIPT_PATH = Path(os.environ["RECEIPT_PATH"])
CHECKER_PATH = Path(os.environ["CHECKER_PATH"])
PRODUCT_MESSAGE = os.environ["PRODUCT_MESSAGE"]
MAINTENANCE_PATHS = [
    "data/MEDIA-SEARCH-LATEST.json",
    "data/journal/media-search.jsonl",
]


def run(
    *args: str,
    capture: bool = True,
    check: bool = True,
    env: dict[str, str] | None = None,
) -> str:
    result = subprocess.run(
        list(args),
        text=True,
        capture_output=capture,
        check=False,
        env=env,
    )
    if check and result.returncode != 0:
        detail = (result.stderr or result.stdout or f"exit {result.returncode}").strip()
        raise SystemExit(f"{' '.join(args)} failed: {detail}")
    return result.stdout.strip() if capture else ""


def git(*args: str) -> str:
    return run("git", *args)


def stable(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: stable(value[key]) for key in sorted(value)}
    if isinstance(value, list):
        return [stable(item) for item in value]
    return value


def pretty(value: Any) -> str:
    return json.dumps(stable(value), indent=2, ensure_ascii=False) + "\n"


def compact(value: Any) -> str:
    return json.dumps(stable(value), ensure_ascii=False, separators=(",", ":"))


def object_hash(value: Any) -> str:
    return hashlib.sha256(pretty(value).encode()).hexdigest()


def compact_hash(value: Any) -> str:
    return hashlib.sha256(compact(value).encode()).hexdigest()


def file_hash(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(pretty(value), encoding="utf-8")


def verify_identity(
    path: Path,
    field: str,
    expected: str,
    omitted: tuple[str, ...] = (),
) -> dict[str, Any]:
    payload = read_json(path)
    if payload.get(field) != expected:
        raise SystemExit(f"{path} sealed {field} drifted: {payload.get(field)}")
    body = dict(payload)
    body.pop(field, None)
    for key in omitted:
        body.pop(key, None)
    actual = object_hash(body)
    if actual != expected:
        raise SystemExit(f"{path} stable identity mismatch: {actual} != {expected}")
    return payload


def count_queue(state: dict[str, Any]) -> dict[str, int]:
    trek = [row for row in state.get("jobs", []) if row.get("scope") == "star-trek"]
    return {
        "total": len(trek),
        "queued": sum(row.get("status") == "queued" for row in trek),
        "resolved": sum(row.get("status") == "resolved" for row in trek),
        "blocked": sum(row.get("status") == "blocked" for row in trek),
        "rejected": sum(row.get("status") == "rejected" for row in trek),
        "in_flight": sum(
            row.get("status") in {"leased", "drafted", "merged"} for row in trek
        ),
    }


def asset_src(value: Any) -> str | None:
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        return value.get("src")
    return None


def verify_input_documents() -> dict[str, Any]:
    docs = {
        "claim": verify_identity(
            OUT / "claim-receipt.json",
            "receipt_sha256",
            CLAIM_RECEIPT_SHA,
            ("artifact",),
        ),
        "source": verify_identity(
            OUT / "source-review.json",
            "review_sha256",
            SOURCE_REVIEW_SHA,
            ("artifact",),
        ),
        "media": verify_identity(
            OUT / "media-receipt.json",
            "receipt_sha256",
            MEDIA_RECEIPT_SHA,
            ("artifact",),
        ),
        "media_review": verify_identity(
            OUT / "media-review.json",
            "review_sha256",
            MEDIA_REVIEW_SHA,
            ("artifact",),
        ),
        "candidate": verify_identity(
            OUT / "candidate-receipt.json",
            "receipt_sha256",
            CANDIDATE_RECEIPT_SHA,
        ),
        "review": verify_identity(
            OUT / "independent-review.json",
            "review_sha256",
            REVIEW_SHA,
            ("artifact",),
        ),
        "predecessor": verify_identity(
            PREDECESSOR_RECEIPT_PATH,
            "receipt_sha256",
            PREDECESSOR_RECEIPT_SHA,
        ),
    }

    if file_hash(PREDECESSOR_CHECKER_PATH) != PREDECESSOR_CHECKER_SHA:
        raise SystemExit("Benbassat predecessor checker identity drifted")

    claim = docs["claim"]
    candidate = docs["candidate"]
    review = docs["review"]
    source = docs["source"]
    media = docs["media"]
    media_review = docs["media_review"]

    if (
        claim.get("transaction") != "STAR-TREK-MORGO-CLAIM-V1"
        or claim.get("lease", {}).get("id") != LEASE_ID
        or claim.get("task", {}).get("id") != TASK_ID
    ):
        raise SystemExit("Morgo claim custody drifted")

    if (
        source.get("verdict") != "pass"
        or source.get("adjudication", {}).get("performance_mode") != "voice-animation"
        or source.get("adjudication", {}).get("episode")
        != "The Least Dangerous Game"
    ):
        raise SystemExit("Morgo source-review boundary drifted")

    if (
        media.get("task", {}).get("id") != TASK_ID
        or media.get("task", {}).get("lease_id") != LEASE_ID
    ):
        raise SystemExit("Morgo media custody drifted")

    if (
        media_review.get("verdict") != "pass"
        or media_review.get("status") != "media-review-complete"
        or media_review.get("boundary", {}).get("candidate_staging_admissible")
        is not True
    ):
        raise SystemExit("Morgo media-review boundary drifted")

    if (
        candidate.get("transaction") != "STAR-TREK-MORGO-CANDIDATE-V1"
        or candidate.get("status") != "candidate-ready-for-independent-review"
        or candidate.get("canonical_parent") != PREDECESSOR_PRODUCT
        or candidate.get("claim_commit") != CLAIM_COMMIT
        or candidate.get("publication_base", {}).get("commit") != LIVE_MAIN
        or candidate.get("publication_base", {}).get("tree") != LIVE_TREE
    ):
        raise SystemExit("Morgo candidate lineage drifted")

    for label, row in (candidate.get("projection_refresh") or {}).items():
        body = dict(row)
        identity = body.pop("receipt_sha256", None)
        if compact_hash(body) != identity:
            raise SystemExit(f"candidate {label} projection identity drifted")

    if (
        review.get("transaction")
        != "STAR-TREK-MORGO-INDEPENDENT-PRODUCT-REVIEW-V2"
        or review.get("verdict") != "pass"
        or review.get("candidate", {}).get("commit") != CANDIDATE_COMMIT
        or review.get("candidate", {}).get("tree") != CANDIDATE_TREE
        or review.get("candidate", {}).get("receipt_sha256")
        != CANDIDATE_RECEIPT_SHA
        or review.get("task", {}).get("lease_id") != LEASE_ID
        or review.get("boundary", {}).get("all_four_media_claims_enforced")
        is not True
    ):
        raise SystemExit("Morgo independent review custody drifted")

    expected_false = (
        "physical_performance_attributed",
        "prosthetic_performance_attributed",
        "animation_labor_attributed",
        "character_design_attributed",
        "voice_direction_attributed",
        "vocal_processing_attributed",
        "sound_attributed",
        "transformation_measured",
        "canonical_mutation",
        "lease_mutation",
        "additional_lease_issued",
        "waterline_cycle_recorded",
    )
    for key in expected_false:
        if review.get("boundary", {}).get(key) is not False:
            raise SystemExit(f"review boundary {key} drifted")
    if review.get("boundary", {}).get("maker_attribution") != "unresolved":
        raise SystemExit("review maker boundary drifted")

    return docs


def verify_candidate_tree() -> tuple[dict[str, Any], dict[str, Any], list[dict[str, Any]]]:
    state = read_json(Path("data/AUTOPILOT.json"))
    counts = count_queue(state)
    expected = {
        "total": 2228,
        "queued": 1796,
        "resolved": 430,
        "blocked": 0,
        "rejected": 2,
        "in_flight": 0,
    }
    if counts != expected:
        raise SystemExit(f"Morgo candidate queue drifted: {counts}")

    matches = [
        row
        for row in state.get("jobs", [])
        if row.get("scope") == "star-trek" and row.get("id") == TASK_ID
    ]
    if len(matches) != 1:
        raise SystemExit(f"Morgo durable task cardinality drifted: {len(matches)}")
    task = matches[0]
    if (
        task.get("status") != "resolved"
        or task.get("attempts") != 1
        or task.get("performer") != PERFORMER
        or task.get("character") != CHARACTER
        or task.get("source_fingerprint") != FINGERPRINT
        or task.get("lease") is not None
        or task.get("wall_ids") != [WALL_ID]
        or task.get("outcome", {}).get("kind") != "audited-wall"
        or task.get("outcome", {}).get("media_review", {}).get("lease_id")
        != LEASE_ID
    ):
        raise SystemExit(f"Morgo durable task drifted: {task}")

    records = [
        row for row in read_json(Path("data/specimens.json")) if row.get("id") == WALL_ID
    ]
    if len(records) != 1:
        raise SystemExit(f"Morgo record cardinality drifted: {len(records)}")
    record = records[0]
    exact = {
        "actor": PERFORMER,
        "character": CHARACTER,
        "production": "The Least Dangerous Game",
        "universe": "Star Trek",
        "years": "2022",
        "kind": "voice",
        "designer": "—",
        "transform": 2,
    }
    for key, expected_value in exact.items():
        if record.get(key) != expected_value:
            raise SystemExit(f"Morgo record {key} drifted: {record.get(key)}")

    if asset_src(record.get("still")) != "images/uc-1398-still.webp":
        raise SystemExit("Morgo still path drifted")
    if asset_src(record.get("portrait")) != "images/uc-1398-portrait.jpg":
        raise SystemExit("Morgo portrait path drifted")
    if file_hash(Path("images/uc-1398-still.webp")) != STILL_SHA:
        raise SystemExit("Morgo still bytes drifted")
    if file_hash(Path("images/uc-1398-portrait.jpg")) != PORTRAIT_SHA:
        raise SystemExit("Morgo portrait bytes drifted")

    audit = read_json(Path("data/MEDIA-AUDIT.json"))
    facets = [
        row
        for row in audit.get("items", [])
        if row.get("wall_id") == WALL_ID and row.get("side") in {"still", "portrait"}
    ]
    if len(facets) != 2:
        raise SystemExit(f"Morgo media facet cardinality drifted: {len(facets)}")

    expected_facets = {
        "still": (STILL_ITEM, STILL_SHA, "expected", "character-depiction"),
        "portrait": (PORTRAIT_ITEM, PORTRAIT_SHA, "expected", "neutral-human"),
    }
    for facet in facets:
        item_id, digest, identity_value, presentation_value = expected_facets[
            facet["side"]
        ]
        claims = facet.get("claims") or {}
        identity = claims.get("identity") or {}
        presentation = claims.get("presentation") or {}
        if (
            facet.get("id") != item_id
            or facet.get("status") != "verified"
            or (facet.get("asset") or {}).get("sha256") != digest
            or identity.get("state") != "enforced"
            or identity.get("value") != identity_value
            or presentation.get("state") != "enforced"
            or presentation.get("value") != presentation_value
        ):
            raise SystemExit(f"Morgo {facet['side']} facet drifted")
        if len(facet.get("votes") or []) != 2:
            raise SystemExit(f"Morgo {facet['side']} vote cardinality drifted")
        if any(vote.get("asset_sha256") != digest for vote in facet["votes"]):
            raise SystemExit(f"Morgo {facet['side']} vote hash drifted")

    source_rows = [
        row for row in read_json(Path("data/SOURCES.json")) if row.get("id") == WALL_ID
    ]
    if len(source_rows) != 1:
        raise SystemExit("Morgo SOURCES cardinality drifted")
    source_row = source_rows[0]
    if (
        source_row.get("actor") != PERFORMER
        or source_row.get("character") != CHARACTER
        or asset_src(source_row.get("still")) != "images/uc-1398-still.webp"
        or asset_src(source_row.get("portrait"))
        != "images/uc-1398-portrait.jpg"
    ):
        raise SystemExit("Morgo SOURCES custody drifted")

    return counts, record, facets


def checker_source() -> str:
    constants = {
        "TASK_ID": TASK_ID,
        "PERFORMER": PERFORMER,
        "CHARACTER": CHARACTER,
        "FINGERPRINT": FINGERPRINT,
        "LEASE_ID": LEASE_ID,
        "WALL_ID": WALL_ID,
        "LIVE_MAIN": LIVE_MAIN,
        "LIVE_TREE": LIVE_TREE,
        "CANDIDATE_COMMIT": CANDIDATE_COMMIT,
        "CANDIDATE_TREE": CANDIDATE_TREE,
        "CANDIDATE_RECEIPT_SHA": CANDIDATE_RECEIPT_SHA,
        "REVIEW_SHA": REVIEW_SHA,
        "PREDECESSOR_RECEIPT_SHA": PREDECESSOR_RECEIPT_SHA,
        "PREDECESSOR_CHECKER_SHA": PREDECESSOR_CHECKER_SHA,
        "PREDECESSOR_CYCLE_ID": PREDECESSOR_CYCLE_ID,
        "STILL_SHA": STILL_SHA,
        "PORTRAIT_SHA": PORTRAIT_SHA,
        "STILL_ITEM": STILL_ITEM,
        "PORTRAIT_ITEM": PORTRAIT_ITEM,
    }
    encoded = json.dumps(constants, ensure_ascii=False)
    return f"""#!/usr/bin/env node
import fs from 'node:fs';
import crypto from 'node:crypto';

const C = {encoded};
const read = (path) => JSON.parse(fs.readFileSync(path, 'utf8'));
const stable = (value) => Array.isArray(value)
  ? value.map(stable)
  : value && typeof value === 'object'
    ? Object.fromEntries(Object.keys(value).sort().map((key) => [key, stable(value[key])]))
    : value;
const digestObject = (value) => crypto.createHash('sha256').update(JSON.stringify(stable(value), null, 2) + '\\n').digest('hex');
const digestCompact = (value) => crypto.createHash('sha256').update(JSON.stringify(stable(value))).digest('hex');
const digestFile = (path) => crypto.createHash('sha256').update(fs.readFileSync(path)).digest('hex');
const fail = (message) => {{ throw new Error(`star-trek-morgo-cycle: ${{message}}`); }};
const assetSrc = (value) => typeof value === 'string' ? value : value?.src;

const receiptPath = 'data/review/adapter-sdk/star-trek-morgo-cycle.json';
const checkerPath = 'scripts/star-trek-morgo-cycle.mjs';
const receipt = read(receiptPath);
const receiptBody = {{...receipt}};
delete receiptBody.receipt_sha256;
if (digestObject(receiptBody) !== receipt.receipt_sha256) fail('receipt identity drifted');
if (digestFile(checkerPath) !== receipt.qualification?.checker_sha256) fail('checker identity drifted');
if (receipt.transaction !== 'STAR-TREK-CYCLE-MORGO' || receipt.version !== 1) fail('receipt transaction drifted');
if (receipt.canonical_parent !== C.LIVE_MAIN || receipt.maintenance_parent?.tree !== C.LIVE_TREE) fail('publication base drifted');
if (receipt.task?.id !== C.TASK_ID || receipt.task?.performer !== C.PERFORMER || receipt.task?.character !== C.CHARACTER || receipt.task?.source_fingerprint !== C.FINGERPRINT) fail('task identity drifted');
if (receipt.task?.production !== 'The Least Dangerous Game' || receipt.task?.series !== 'Star Trek: Lower Decks' || receipt.task?.years !== '2022' || receipt.task?.performance_mode !== 'voice-animation') fail('performance object drifted');
for (const key of ['physical_performance_attributed','prosthetic_performance_attributed','animation_labor_attributed','character_design_attributed','voice_direction_attributed','vocal_processing_attributed','sound_attributed','transformation_measured']) {{
  if (receipt.task?.[key] !== false) fail(`unsupported attribution promoted: ${{key}}`);
}}
if (receipt.task?.maker_attribution !== 'unresolved') fail('maker attribution drifted');
if (receipt.lease?.id !== C.LEASE_ID || receipt.canonical?.wall_id !== C.WALL_ID) fail('lease or wall custody drifted');
if (receipt.candidate?.commit !== C.CANDIDATE_COMMIT || receipt.candidate?.tree !== C.CANDIDATE_TREE || receipt.candidate?.receipt_sha256 !== C.CANDIDATE_RECEIPT_SHA) fail('candidate custody drifted');
if (receipt.independent_review?.review_sha256 !== C.REVIEW_SHA || receipt.independent_review?.verdict !== 'pass') fail('independent review drifted');
if (receipt.predecessor?.receipt_sha256 !== C.PREDECESSOR_RECEIPT_SHA || receipt.predecessor?.checker_sha256 !== C.PREDECESSOR_CHECKER_SHA || receipt.predecessor?.cycle_id !== C.PREDECESSOR_CYCLE_ID) fail('Benbassat predecessor custody drifted');

const predecessor = read('data/review/adapter-sdk/star-trek-benbassat-cycle.json');
const predecessorBody = {{...predecessor}};
delete predecessorBody.receipt_sha256;
if (digestObject(predecessorBody) !== C.PREDECESSOR_RECEIPT_SHA || predecessor.receipt_sha256 !== C.PREDECESSOR_RECEIPT_SHA) fail('Benbassat receipt identity drifted');
if (digestFile('scripts/star-trek-benbassat-cycle.mjs') !== C.PREDECESSOR_CHECKER_SHA) fail('Benbassat checker identity drifted');

const candidate = read('data/review/adapter-sdk/star-trek-morgo-candidate.json');
const candidateBody = {{...candidate}};
delete candidateBody.receipt_sha256;
if (digestObject(candidateBody) !== C.CANDIDATE_RECEIPT_SHA || candidate.receipt_sha256 !== C.CANDIDATE_RECEIPT_SHA) fail('candidate receipt identity drifted');
for (const key of ['precomplete','terminal']) {{
  const row = candidate.projection_refresh?.[key];
  if (!row) fail(`candidate ${{key}} census receipt missing`);
  const body = {{...row}};
  delete body.receipt_sha256;
  if (digestCompact(body) !== row.receipt_sha256) fail(`candidate ${{key}} census identity drifted`);
}}

const state = read('data/AUTOPILOT.json');
const trek = state.jobs.filter((row) => row.scope === 'star-trek');
const task = trek.find((row) => row.id === C.TASK_ID);
if (!task || task.status !== 'resolved' || task.attempts !== 1 || task.performer !== C.PERFORMER || task.character !== C.CHARACTER || task.source_fingerprint !== C.FINGERPRINT || task.lease != null || task.outcome?.media_review?.lease_id !== C.LEASE_ID || JSON.stringify(task.wall_ids) !== JSON.stringify([C.WALL_ID])) fail('durable task drifted');
if (trek.length !== 2228) fail('Star Trek denominator drifted');
if (trek.filter((row) => row.status === 'resolved').length < 430) fail('resolved floor regressed');
if (trek.filter((row) => ['leased','drafted','merged'].includes(row.status)).length > 1) fail('later-cycle active-task bound exceeded');

const water = read('data/WATERLINE-STATE.json');
const cycle = water.cycles.find((row) => row.id === receipt.reviewed_cycle?.id && row.scope_id === 'star-trek' && row.lease_id === C.LEASE_ID);
if (!cycle || cycle.outcome !== 'completed' || cycle.task_statuses?.[C.TASK_ID] !== 'resolved') fail('waterline custody drifted');
if (!water.cycles.some((row) => row.id === C.PREDECESSOR_CYCLE_ID && row.outcome === 'completed')) fail('Benbassat predecessor cycle missing');

const records = read('data/specimens.json').filter((row) => row.id === C.WALL_ID);
if (records.length !== 1) fail(`canonical record cardinality drifted (${{records.length}})`);
const record = records[0];
if (record.actor !== C.PERFORMER || record.character !== C.CHARACTER || record.production !== 'The Least Dangerous Game' || record.years !== '2022' || record.kind !== 'voice' || record.designer !== '—' || record.transform !== 2) fail('canonical record boundary drifted');
if (assetSrc(record.still) !== 'images/uc-1398-still.webp' || assetSrc(record.portrait) !== 'images/uc-1398-portrait.jpg') fail('canonical media paths drifted');
if (digestFile('images/uc-1398-still.webp') !== C.STILL_SHA || digestFile('images/uc-1398-portrait.jpg') !== C.PORTRAIT_SHA) fail('canonical media bytes drifted');

const audit = read('data/MEDIA-AUDIT.json');
const facets = audit.items.filter((row) => row.wall_id === C.WALL_ID && ['still','portrait'].includes(row.side));
if (facets.length !== 2 || new Set(facets.map((row) => row.side)).size !== 2) fail('media facet cardinality drifted');
for (const facet of facets) {{
  const expected = facet.side === 'still'
    ? {{id:C.STILL_ITEM, sha:C.STILL_SHA, presentation:'character-depiction'}}
    : {{id:C.PORTRAIT_ITEM, sha:C.PORTRAIT_SHA, presentation:'neutral-human'}};
  if (facet.id !== expected.id || facet.status !== 'verified' || facet.asset?.sha256 !== expected.sha || facet.claims?.identity?.state !== 'enforced' || facet.claims?.identity?.value !== 'expected' || facet.claims?.presentation?.state !== 'enforced' || facet.claims?.presentation?.value !== expected.presentation || facet.votes?.length !== 2 || facet.votes.some((vote) => vote.asset_sha256 !== expected.sha)) fail(`${{facet.side}} media custody drifted`);
}}

const sourceRows = read('data/SOURCES.json').filter((row) => row.id === C.WALL_ID);
if (sourceRows.length !== 1 || sourceRows[0].actor !== C.PERFORMER || sourceRows[0].character !== C.CHARACTER || assetSrc(sourceRows[0].still) !== 'images/uc-1398-still.webp' || assetSrc(sourceRows[0].portrait) !== 'images/uc-1398-portrait.jpg') fail('SOURCES custody drifted');

const registry = read('data/ESTATE-REGISTRY.json');
const estate = registry.estates.find((row) => row.id === 'star-trek');
if (!estate || digestFile('data/ESTATE-REGISTRY.json') !== receipt.registry?.sha256 || crypto.createHash('sha256').update(estate.next_gate).digest('hex') !== receipt.registry?.next_gate_sha256) fail('estate registry custody drifted');
if (!fs.readFileSync('sitemap.xml', 'utf8').includes(`records/${{C.WALL_ID}}/`)) fail('permanent route missing');

console.log('star-trek-morgo-cycle: PASS — Fred Tatasciore voice-animation custody, exact Morgo and performer media, reviewed waterline closure, maintenance-parent preservation, Benbassat predecessor custody, and later-cycle bounds are intact');
"""


def update_package() -> None:
    path = Path("package.json")
    package = read_json(path)
    scripts = dict(package.get("scripts") or {})
    command = "node scripts/star-trek-morgo-cycle.mjs"
    existing = scripts.get("star-trek:morgo-cycle:check")
    if existing not in (None, command):
        raise SystemExit("package Morgo checker script drifted")
    scripts["star-trek:morgo-cycle:check"] = command

    fixtures = scripts.get("autopilot:fixtures")
    if not isinstance(fixtures, str):
        raise SystemExit("autopilot fixture script missing")
    invocation = "npm run star-trek:morgo-cycle:check"
    if invocation not in fixtures:
        scripts["autopilot:fixtures"] = fixtures + " && " + invocation

    package["scripts"] = {key: scripts[key] for key in sorted(scripts)}
    path.write_text(json.dumps(package, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def prepare() -> None:
    OUT.mkdir(parents=True, exist_ok=True)

    if git("rev-parse", "refs/remotes/origin/main") != LIVE_MAIN:
        raise SystemExit("origin/main moved before finalization")
    if git("show", "-s", "--format=%T", LIVE_MAIN) != LIVE_TREE:
        raise SystemExit("live tree drifted")
    if git("show", "-s", "--format=%P", LIVE_MAIN) != PREDECESSOR_PRODUCT:
        raise SystemExit("live maintenance parent drifted")
    if git("show", "-s", "--format=%s", LIVE_MAIN) != LIVE_MESSAGE:
        raise SystemExit("live maintenance message drifted")

    changed = sorted(
        line
        for line in git("diff", "--name-only", f"{PREDECESSOR_PRODUCT}..{LIVE_MAIN}").splitlines()
        if line
    )
    if changed != sorted(MAINTENANCE_PATHS):
        raise SystemExit(f"live maintenance path set drifted: {changed}")

    checks = {
        "claim commit": (git("rev-parse", "refs/remotes/origin/" + os.environ["CLAIM_BRANCH"]), CLAIM_COMMIT),
        "candidate commit": (git("rev-parse", "refs/remotes/origin/" + os.environ["CANDIDATE_BRANCH"]), CANDIDATE_COMMIT),
        "candidate tree": (git("show", "-s", "--format=%T", CANDIDATE_COMMIT), CANDIDATE_TREE),
        "candidate parent": (git("show", "-s", "--format=%P", CANDIDATE_COMMIT), CLAIM_COMMIT),
        "review commit": (git("rev-parse", "refs/remotes/origin/" + os.environ["REVIEW_BRANCH"]), REVIEW_COMMIT),
        "source review commit": (git("rev-parse", "refs/remotes/origin/" + os.environ["SOURCE_REVIEW_BRANCH"]), os.environ["SOURCE_REVIEW_COMMIT"]),
        "media commit": (git("rev-parse", "refs/remotes/origin/" + os.environ["MEDIA_BRANCH"]), os.environ["MEDIA_COMMIT"]),
        "media review commit": (git("rev-parse", "refs/remotes/origin/" + os.environ["MEDIA_REVIEW_BRANCH"]), os.environ["MEDIA_REVIEW_COMMIT"]),
    }
    for label, (actual, expected) in checks.items():
        if actual != expected:
            raise SystemExit(f"{label} drifted: {actual} != {expected}")

    if git("show", "-s", "--format=%s", CANDIDATE_COMMIT) != "Star Trek: stage reviewed Morgo candidate v1":
        raise SystemExit("candidate message drifted")
    if git("show", "-s", "--format=%P", CLAIM_COMMIT) != PREDECESSOR_PRODUCT:
        raise SystemExit("claim parent drifted")
    if git("show", "-s", "--format=%T", CLAIM_COMMIT) != CLAIM_TREE:
        raise SystemExit("claim tree drifted")

    git("checkout", "--detach", CANDIDATE_COMMIT)
    git("clean", "-fdx")

    if git("rev-parse", f"{CANDIDATE_COMMIT}:.github") != git(
        "rev-parse", f"{LIVE_MAIN}:.github"
    ):
        raise SystemExit("candidate workflow subtree drifted from live main")

    for path in MAINTENANCE_PATHS:
        git("checkout", LIVE_MAIN, "--", path)

    docs = verify_input_documents()
    counts, record, facets = verify_candidate_tree()

    run("npm", "ci", "--ignore-scripts", capture=False)

    waterline = read_json(Path("data/WATERLINE-STATE.json"))
    existing = [
        row
        for row in waterline.get("cycles", [])
        if row.get("scope_id") == "star-trek" and row.get("lease_id") == LEASE_ID
    ]
    if existing:
        raise SystemExit("Morgo waterline cycle already exists in candidate tree")

    review = docs["review"]
    cycle_input = {
        "scope_id": "star-trek",
        "lease_id": LEASE_ID,
        "outcome": "completed",
        "note": (
            "The reviewed Morgo cycle resolves Fred Tatasciore’s animated voice "
            "performance as Volcanic Lord Morgo in Star Trek: Lower Decks episode "
            "The Least Dangerous Game (2022), preserves the exact primary Morgo still "
            "and separately encoded licensed performer portrait, and leaves unsupported "
            "physical, prosthetic, animation-labor, character-design, direction, "
            "processing, sound, transformation, production-shop, and maker functions "
            "unattributed."
        ),
        "evidence": [
            {
                "type": "workflow-run",
                "value": (
                    f"github-actions-artifact:{review.get('artifact', {}).get('id')}:"
                    f"{review.get('artifact', {}).get('digest')}"
                ),
            },
            {"type": "commit", "value": CANDIDATE_COMMIT},
            {
                "type": "restart-proof",
                "value": (
                    f"candidate-receipt:{CANDIDATE_RECEIPT_SHA};"
                    f"independent-review:{REVIEW_SHA};lease:{LEASE_ID}"
                ),
            },
        ],
        "reviewed_by": review["reviewer"],
        "reviewed_role": "second-desk",
        "reviewed_at": review["reviewed_at"],
    }
    write_json(OUT / "cycle-input.json", cycle_input)
    run(
        "node",
        "scripts/waterline.mjs",
        "record-cycle",
        "--input",
        str(OUT / "cycle-input.json"),
        capture=False,
    )

    waterline = read_json(Path("data/WATERLINE-STATE.json"))
    cycles = [
        row
        for row in waterline.get("cycles", [])
        if row.get("scope_id") == "star-trek" and row.get("lease_id") == LEASE_ID
    ]
    if len(cycles) != 1:
        raise SystemExit(f"Morgo waterline cardinality drifted: {len(cycles)}")
    cycle = cycles[0]
    if (
        cycle.get("outcome") != "completed"
        or cycle.get("task_statuses", {}).get(TASK_ID) != "resolved"
        or cycle.get("reviewed_by") != review["reviewer"]
        or cycle.get("reviewed_at") != review["reviewed_at"]
    ):
        raise SystemExit("Morgo waterline receipt drifted")

    next_text = run("node", "scripts/thesis-rails.mjs", "next", "--json")
    next_doc = json.loads(next_text)
    if next_doc.get("phase") != "ready-for-one-cycle":
        raise SystemExit(f"post-cycle rail is not ready: {next_doc}")
    write_json(OUT / "next.json", next_doc)

    registry_path = Path("data/ESTATE-REGISTRY.json")
    registry = read_json(registry_path)
    estate = next(
        (row for row in registry.get("estates", []) if row.get("id") == "star-trek"),
        None,
    )
    if estate is None:
        raise SystemExit("Star Trek estate registry entry missing")
    next_candidate = next_doc.get("candidate") or {}
    next_label = (
        f"{next_candidate.get('performer')} as {next_candidate.get('character')} "
        f"({next_candidate.get('task_id')})"
        if next_candidate
        else "the next repository-native thesis candidate"
    )
    next_gate = (
        f"Star Trek reviewed Morgo cycle {cycle['id']} resolved Fred Tatasciore’s "
        "animated voice performance as Volcanic Lord Morgo in Star Trek: Lower Decks "
        f"episode The Least Dangerous Game (2022) within the preserved {counts['total']:,}-task "
        f"denominator; {counts['queued']:,} tasks remain queued. The exact primary Morgo "
        "still and a separately encoded licensed Fred Tatasciore portrait are verified "
        "through four hash-bound second-desk claims. Physical performance, prosthetic "
        "performance, animation labor, character design, voice direction, vocal processing, "
        "sound, editing, production-shop labor, transformation measurement, and every "
        f"unsupported maker function remain unresolved. The reproduced rail selects {next_label}. "
        "Any later cycle must claim at most one compatible task and return to a reviewed "
        "cycle receipt before another claim."
    )
    estate["next_gate"] = next_gate
    write_json(registry_path, registry)
    registry_sha = file_hash(registry_path)

    baseline_path = Path("data/review/adapter-sdk/BASELINE.json")
    baseline = read_json(baseline_path)
    estate_input = (baseline.get("inputs") or {}).get("estate_registry")
    if not isinstance(estate_input, dict):
        raise SystemExit("adapter baseline estate registry binding missing")
    estate_input["sha256"] = registry_sha
    write_json(baseline_path, baseline)

    CHECKER_PATH.parent.mkdir(parents=True, exist_ok=True)
    CHECKER_PATH.write_text(checker_source(), encoding="utf-8")
    checker_sha = file_hash(CHECKER_PATH)

    maintenance_hashes = {
        path: file_hash(Path(path)) for path in MAINTENANCE_PATHS
    }
    record_sha = object_hash(record)
    facets_sha = object_hash(facets)

    receipt = {
        "version": 1,
        "transaction": "STAR-TREK-CYCLE-MORGO",
        "generated_at": review["reviewed_at"],
        "canonical_parent": LIVE_MAIN,
        "historical_claim_parent": {
            "commit": PREDECESSOR_PRODUCT,
            "tree": PREDECESSOR_TREE,
        },
        "maintenance_parent": {
            "commit": LIVE_MAIN,
            "tree": LIVE_TREE,
            "parent": PREDECESSOR_PRODUCT,
            "paths": MAINTENANCE_PATHS,
            "sha256": maintenance_hashes,
        },
        "claim": {
            "commit": CLAIM_COMMIT,
            "tree": CLAIM_TREE,
            "receipt_sha256": CLAIM_RECEIPT_SHA,
        },
        "candidate": {
            "commit": CANDIDATE_COMMIT,
            "tree": CANDIDATE_TREE,
            "receipt_sha256": CANDIDATE_RECEIPT_SHA,
            "publication_base": docs["candidate"]["publication_base"],
            "changed_paths": docs["review"]["candidate"]["paths"],
        },
        "independent_review": {
            "branch": os.environ["REVIEW_BRANCH"],
            "commit": REVIEW_COMMIT,
            "review_sha256": REVIEW_SHA,
            "reviewer": review["reviewer"],
            "reviewed_role": review["reviewed_role"],
            "reviewed_at": review["reviewed_at"],
            "verdict": review["verdict"],
            "artifact": review["artifact"],
            "gates": review["gates"],
        },
        "lease": docs["claim"]["lease"],
        "canonical": {
            "wall_id": WALL_ID,
            "record": record,
            "record_sha256": record_sha,
        },
        "source_review": {
            "branch": os.environ["SOURCE_REVIEW_BRANCH"],
            "commit": os.environ["SOURCE_REVIEW_COMMIT"],
            "review_sha256": SOURCE_REVIEW_SHA,
            "verdict": docs["source"]["verdict"],
            "adjudication": docs["source"]["adjudication"],
        },
        "media": {
            "receipt_sha256": MEDIA_RECEIPT_SHA,
            "review_sha256": MEDIA_REVIEW_SHA,
            "facets": facets,
            "facets_sha256": facets_sha,
            "still_sha256": STILL_SHA,
            "portrait_sha256": PORTRAIT_SHA,
        },
        "predecessor": {
            "character": "Benbassat",
            "task_id": "ap_dd7d1c73ed237230cd6e1d0b",
            "receipt_path": str(PREDECESSOR_RECEIPT_PATH),
            "receipt_sha256": PREDECESSOR_RECEIPT_SHA,
            "checker_path": str(PREDECESSOR_CHECKER_PATH),
            "checker_sha256": PREDECESSOR_CHECKER_SHA,
            "cycle_id": PREDECESSOR_CYCLE_ID,
        },
        "projection_refresh": docs["candidate"]["projection_refresh"],
        "reviewed_cycle": {
            **cycle,
            "prior_cycle_id": PREDECESSOR_CYCLE_ID,
        },
        "queue": {
            "before": docs["claim"]["queue"]["after"],
            "after": counts,
        },
        "registry": {
            "path": str(registry_path),
            "estate_id": "star-trek",
            "reviewed_cycle_id": cycle["id"],
            "queued": counts["queued"],
            "next_gate": next_gate,
            "next_gate_sha256": hashlib.sha256(next_gate.encode()).hexdigest(),
            "sha256": registry_sha,
        },
        "next": next_doc,
        "qualification": {
            "checker_path": str(CHECKER_PATH),
            "checker_sha256": checker_sha,
            "denominator": counts["total"],
            "resolved_floor": counts["resolved"],
        },
        "boundary": {
            "exact_morgo_character": True,
            "primary_morgo_still": True,
            "automatic_crater_page_image_excluded": True,
            "performer_source_reuse_admitted": True,
            "source_distinct_media": True,
            "cross_facet_substitution": False,
            "all_four_media_claims_enforced": True,
            "physical_performance_attributed": False,
            "prosthetic_performance_attributed": False,
            "animation_labor_attributed": False,
            "character_design_attributed": False,
            "voice_direction_attributed": False,
            "vocal_processing_attributed": False,
            "sound_attributed": False,
            "transformation_measured": False,
            "maker_attribution": "unresolved",
            "additional_lease_issued": False,
        },
        "task": {
            "id": TASK_ID,
            "performer": PERFORMER,
            "character": CHARACTER,
            "source_fingerprint": FINGERPRINT,
            "production": "The Least Dangerous Game",
            "series": "Star Trek: Lower Decks",
            "years": "2022",
            "adjudicated_kind": "voice",
            "performance_mode": "voice-animation",
            "performance_scope": (
                "Fred Tatasciore’s animated voice performance as Volcanic Lord Morgo "
                "in the Star Trek: Lower Decks episode The Least Dangerous Game (2022)."
            ),
            "physical_performance_attributed": False,
            "prosthetic_performance_attributed": False,
            "animation_labor_attributed": False,
            "character_design_attributed": False,
            "voice_direction_attributed": False,
            "vocal_processing_attributed": False,
            "sound_attributed": False,
            "transformation_measured": False,
            "maker_attribution": "unresolved",
        },
    }
    receipt["receipt_sha256"] = object_hash(receipt)
    write_json(RECEIPT_PATH, receipt)

    update_package()

    run("node", str(CHECKER_PATH), capture=False)
    run("node", "scripts/validate.mjs", capture=False)
    run("npm", "run", "media:audit", "--", "gate", "--scope", "star-trek", capture=False)
    run("node", "scripts/waterline.mjs", "validate", capture=False)
    run("node", "scripts/thesis-rails.mjs", "validate", capture=False)
    run("npm", "run", "autopilot:fixtures", capture=False)

    run("git", "diff", "--check", capture=False)

    actual = {
        line
        for line in git("diff", "--name-only", CANDIDATE_COMMIT).splitlines()
        if line
    }
    allowed = {
        *MAINTENANCE_PATHS,
        "data/WATERLINE-STATE.json",
        "data/journal/waterline.jsonl",
        "data/ESTATE-REGISTRY.json",
        "data/review/adapter-sdk/BASELINE.json",
        str(RECEIPT_PATH),
        str(CHECKER_PATH),
        "package.json",
    }
    required = {
        *MAINTENANCE_PATHS,
        "data/WATERLINE-STATE.json",
        "data/journal/waterline.jsonl",
        "data/ESTATE-REGISTRY.json",
        "data/review/adapter-sdk/BASELINE.json",
        str(RECEIPT_PATH),
        str(CHECKER_PATH),
        "package.json",
    }
    if not actual.issubset(allowed):
        raise SystemExit(f"finalizer changed unauthorized paths: {sorted(actual - allowed)}")
    if not required.issubset(actual):
        raise SystemExit(f"finalizer omitted required paths: {sorted(required - actual)}")

    candidate_paths = {
        line
        for line in git("diff-tree", "--no-commit-id", "--name-only", "-r", CANDIDATE_COMMIT).splitlines()
        if line
    }
    if any(
        path.startswith(".github/")
        or path.startswith("transport/")
        or "__pycache__" in path
        or path.endswith(".pyc")
        for path in candidate_paths
    ):
        raise SystemExit("candidate contains transport residue")

    git("add", "-A")
    tree = git("write-tree")

    commit_env = os.environ.copy()
    commit_env.update(
        {
            "GIT_AUTHOR_NAME": "undercast-morgo-terminalizer-v2",
            "GIT_AUTHOR_EMAIL": "undercast-morgo-terminalizer-v2@users.noreply.github.com",
            "GIT_AUTHOR_DATE": review["reviewed_at"],
            "GIT_COMMITTER_NAME": "undercast-morgo-terminalizer-v2",
            "GIT_COMMITTER_EMAIL": "undercast-morgo-terminalizer-v2@users.noreply.github.com",
            "GIT_COMMITTER_DATE": review["reviewed_at"],
        }
    )
    product_commit = run(
        "git",
        "commit-tree",
        tree,
        "-p",
        LIVE_MAIN,
        "-m",
        PRODUCT_MESSAGE,
        env=commit_env,
    )

    if git("show", "-s", "--format=%P", product_commit) != LIVE_MAIN:
        raise SystemExit("product parent drifted")
    if git("show", "-s", "--format=%T", product_commit) != tree:
        raise SystemExit("product tree drifted")
    if git("show", "-s", "--format=%s", product_commit) != PRODUCT_MESSAGE:
        raise SystemExit("product message drifted")
    if git("rev-parse", f"{product_commit}:.github") != git(
        "rev-parse", f"{LIVE_MAIN}:.github"
    ):
        raise SystemExit("product workflow subtree is not inherited from live main")

    (OUT / "product-commit.txt").write_text(product_commit + "\n", encoding="utf-8")
    (OUT / "product-tree.txt").write_text(tree + "\n", encoding="utf-8")
    (OUT / "cycle-id.txt").write_text(cycle["id"] + "\n", encoding="utf-8")
    (OUT / "receipt-sha256.txt").write_text(
        receipt["receipt_sha256"] + "\n", encoding="utf-8"
    )
    (OUT / "checker-sha256.txt").write_text(checker_sha + "\n", encoding="utf-8")
    (OUT / "product-paths.txt").write_text(
        "\n".join(sorted(actual)) + "\n", encoding="utf-8"
    )
    write_json(
        OUT / "prepared-publication.json",
        {
            "version": 2,
            "transaction": "STAR-TREK-MORGO-FINALIZER-PREPARED-V2",
            "status": "prepared",
            "product": {
                "commit": product_commit,
                "tree": tree,
                "parent": LIVE_MAIN,
                "message": PRODUCT_MESSAGE,
            },
            "receipt": {
                "path": str(RECEIPT_PATH),
                "sha256": receipt["receipt_sha256"],
                "checker_path": str(CHECKER_PATH),
                "checker_sha256": checker_sha,
            },
            "cycle": cycle,
            "queue": counts,
            "next": next_doc,
            "boundary": {
                "canonical_mutation": False,
                "additional_lease_issued": False,
                "pages_pending": True,
            },
        },
    )

    for path in (RECEIPT_PATH, CHECKER_PATH, Path("data/WATERLINE-STATE.json"), registry_path):
        target = OUT / "product-evidence" / path
        target.parent.mkdir(parents=True, exist_ok=True)
        if path.suffix == ".json":
            target.write_text(path.read_text(encoding="utf-8"), encoding="utf-8")
        else:
            target.write_bytes(path.read_bytes())

    print(product_commit)


if __name__ == "__main__":
    if len(sys.argv) != 2 or sys.argv[1] != "prepare":
        raise SystemExit("usage: finalizer.py prepare")
    prepare()
